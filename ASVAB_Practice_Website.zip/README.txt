
ASVAB Practice Website

To use as a normal website:
1. Create a free GitHub account if you do not have one.
2. Create a new repository named asvab-practice.
3. Upload index.html into the repository.
4. Go to Settings > Pages.
5. Under "Build and deployment", set Source to "Deploy from a branch".
6. Select Branch: main and Folder: /root, then Save.
7. GitHub will give you a website link. Open it in Safari/Chrome and add it to your Home Screen.

You can also open index.html directly in Safari/Chrome after saving it to Files, but hosting it on GitHub Pages is more reliable on iPhone.
